const ramos = [
  { codigo: "ALG", nombre: "Álgebra", prerreq: [] },
  { codigo: "QUI1", nombre: "Química Inorgánica", prerreq: [] },
  { codigo: "BIOCEL", nombre: "Biología Celular Vegetal", prerreq: [] },
  { codigo: "CALC1", nombre: "Cálculo I", prerreq: ["ALG"] },
  { codigo: "QUI2", nombre: "Química Orgánica", prerreq: ["QUI1"] },
  { codigo: "BIOQ", nombre: "Bioquímica Vegetal", prerreq: ["QUI2", "BIOCEL"] },
  // ... más ramos aquí
];

function crearMalla() {
  const contenedor = document.getElementById("malla");
  ramos.forEach(r => {
    const div = document.createElement("div");
    div.classList.add("ramo");
    div.dataset.codigo = r.codigo;
    div.textContent = r.nombre;
    contenedor.appendChild(div);
  });
  actualizarBloqueos();
}

function actualizarBloqueos() {
  document.querySelectorAll(".ramo").forEach(ramo => {
    const cod = ramo.dataset.codigo;
    const datos = ramos.find(r => r.codigo === cod);
    const cumplido = datos.prerreq.every(pr => 
      document.querySelector(`.ramo[data-codigo="${pr}"]`)?.classList.contains("aprobado")
    );
    if (!cumplido && datos.prerreq.length > 0) {
      ramo.classList.add("bloqueado");
    } else {
      ramo.classList.remove("bloqueado");
    }
  });
}

document.addEventListener("DOMContentLoaded", () => {
  crearMalla();
  document.addEventListener("click", e => {
    if (e.target.classList.contains("ramo") && !e.target.classList.contains("bloqueado")) {
      e.target.classList.toggle("aprobado");
      actualizarBloqueos();
    }
  });
});
